package id.ac.usm

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
