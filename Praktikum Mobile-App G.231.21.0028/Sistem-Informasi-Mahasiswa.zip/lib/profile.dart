import 'dart:developer';

import 'edit.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:firebase_database/firebase_database.dart';

final DatabaseReference _databaseReference = FirebaseDatabase.instance.ref();

class ProfilePage extends StatefulWidget {
  final String NIM;
  ProfilePage({required this.NIM});
  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  Map<dynamic, dynamic> mappedData = {};
  String NIM = "";

  @override
  void initState() {
    super.initState();
    NIM = widget.NIM;
    fetchData(NIM);
  }

  Future<void> fetchData(String NIM) async {
    final ref = _databaseReference.child("Mahasiswa").child(NIM);
    final data = await ref.get();
    setState(() {
      mappedData = data.value as Map<dynamic, dynamic>;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Profile Mahasiswa'),
        ),
        body: SingleChildScrollView(
            child: Column(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Center(
                child: FlutterLogo(
                  size: 80.0,
                ),
              ),
            ),
            Padding(
                padding: const EdgeInsets.all(10.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("NIM", style: TextStyle(fontSize: 15)),
                    SizedBox(
                      height: 1,
                    ),
                    Container(
                        width: 300,
                        height: 25,
                        decoration: BoxDecoration(
                            border: Border(
                                bottom:
                                    BorderSide(color: Colors.grey, width: 1))),
                        child: Text(NIM,
                            style: TextStyle(fontSize: 20, height: 1.4))),
                  ],
                )),
            Padding(
                padding: const EdgeInsets.all(10.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Nama", style: TextStyle(fontSize: 15)),
                    SizedBox(
                      height: 1,
                    ),
                    Container(
                        width: 300,
                        height: 25,
                        decoration: BoxDecoration(
                            border: Border(
                                bottom:
                                    BorderSide(color: Colors.grey, width: 1))),
                        child: Text(mappedData['nama'].toString(),
                            style: TextStyle(fontSize: 20, height: 1.4))),
                  ],
                )),
            Padding(
                padding: const EdgeInsets.all(10.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("E-Mail", style: TextStyle(fontSize: 15)),
                    SizedBox(
                      height: 1,
                    ),
                    Container(
                        width: 300,
                        height: 25,
                        decoration: BoxDecoration(
                            border: Border(
                                bottom:
                                    BorderSide(color: Colors.grey, width: 1))),
                        child: Text(mappedData['email'].toString(),
                            style: TextStyle(fontSize: 20, height: 1.4))),
                  ],
                )),
            Container(
                margin: EdgeInsets.only(top: 16.0, left: 16.0, right: 16.0),
                height: 50,
                width: 200,
                decoration: BoxDecoration(
                    color: Colors.blue,
                    borderRadius: BorderRadius.circular(15)),
                child: TextButton(
                    onPressed: () {
                      //TODO Update
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => new EditProfilePage(
                                  NIM: NIM,
                                  Nama: mappedData['nama'],
                                  Email: mappedData['email'])));
                    },
                    child: Text(
                      "Ubah Profil",
                      style: TextStyle(color: Colors.white, fontSize: 25),
                    ))),
            Container(
                margin: EdgeInsets.only(top: 16.0, left: 16.0, right: 16.0),
                height: 50,
                width: 200,
                decoration: BoxDecoration(
                    color: Colors.blue,
                    borderRadius: BorderRadius.circular(15)),
                child: TextButton(
                    onPressed: () {
//TODO Batalkan
                      Navigator.pop(context);
                    },
                    child: Text(
                      "Logout",
                      style: TextStyle(color: Colors.white, fontSize: 25),
                    ))),
          ],
        )));
  }
}
